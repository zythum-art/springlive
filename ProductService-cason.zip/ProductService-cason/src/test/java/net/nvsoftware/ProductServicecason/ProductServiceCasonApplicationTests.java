package net.nvsoftware.ProductServicecason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
