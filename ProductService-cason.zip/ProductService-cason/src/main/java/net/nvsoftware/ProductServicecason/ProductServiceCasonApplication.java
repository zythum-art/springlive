package net.nvsoftware.ProductServicecason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceCasonApplication.class, args);
	}

}
