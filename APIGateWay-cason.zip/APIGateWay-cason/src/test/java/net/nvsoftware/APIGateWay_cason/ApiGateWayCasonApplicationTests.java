package net.nvsoftware.APIGateWay_cason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateWayCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
