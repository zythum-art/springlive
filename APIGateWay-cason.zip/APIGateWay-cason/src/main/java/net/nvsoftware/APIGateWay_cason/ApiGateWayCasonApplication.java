package net.nvsoftware.APIGateWay_cason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGateWayCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGateWayCasonApplication.class, args);
	}

}
