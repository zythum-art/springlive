package net.nvsoftware.ConfigServicecason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServiceCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
