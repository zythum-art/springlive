package net.nvsoftware.ConfigServicecason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServiceCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServiceCasonApplication.class, args);
	}

}
