package net.nvsoftware.ServiceRegistrycason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRegistryCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRegistryCasonApplication.class, args);
	}

}
