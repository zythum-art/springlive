package net.nvsoftware.PaymentService_cason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentServiceCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentServiceCasonApplication.class, args);
	}

}
