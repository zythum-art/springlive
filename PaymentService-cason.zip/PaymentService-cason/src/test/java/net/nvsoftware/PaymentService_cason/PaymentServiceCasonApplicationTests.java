package net.nvsoftware.PaymentService_cason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentServiceCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
