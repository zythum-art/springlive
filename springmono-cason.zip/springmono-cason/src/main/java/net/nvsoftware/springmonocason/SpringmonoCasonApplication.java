package net.nvsoftware.springmonocason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmonoCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmonoCasonApplication.class, args);
	}

}
