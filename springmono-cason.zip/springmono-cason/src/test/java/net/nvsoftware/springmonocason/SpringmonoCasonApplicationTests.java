package net.nvsoftware.springmonocason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmonoCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
