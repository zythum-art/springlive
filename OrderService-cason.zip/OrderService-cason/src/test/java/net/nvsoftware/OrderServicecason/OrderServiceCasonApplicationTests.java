package net.nvsoftware.OrderServicecason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceCasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
