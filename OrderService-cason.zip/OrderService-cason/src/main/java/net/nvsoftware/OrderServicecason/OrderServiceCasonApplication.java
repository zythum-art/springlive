package net.nvsoftware.OrderServicecason;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceCasonApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceCasonApplication.class, args);
	}

}
